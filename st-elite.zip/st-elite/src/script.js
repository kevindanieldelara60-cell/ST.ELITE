function showTab(id,btn){

document.querySelectorAll('.content').forEach(content=>{
content.classList.remove('active-content')
})

document.getElementById(id).classList.add('active-content')

document.querySelectorAll('.tab').forEach(tab=>{
tab.classList.remove('active')
})

btn.classList.add('active')

}